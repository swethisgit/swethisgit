//
//  VideoPlayerViewController.swift
//  VentunoTask
//
//  Created by Sweda Thiyagarajan on 09/03/2022.
//

import UIKit
import AVKit

class VideoPlayerViewController: AVPlayerViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.player?.play()
        // Do any additional setup after loading the view.
    }
}
