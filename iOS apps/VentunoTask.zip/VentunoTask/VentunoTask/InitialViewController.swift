//
//  InitialViewController.swift
//  VentunoTask
//
//  Created by Sweda Thiyagarajan on 07/03/2022.
//

import UIKit
import AVKit

class InitialViewController: UIViewController {

    var overlayViewController: OverlayViewController!
    var avPlayer : VideoPlayerViewController!
    
    //MARK: - View methods
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    //MARK: - IBAction
    @IBAction func startDownload(_ sender: Any) {
        let storagePath = getDocumentsDirectory()
        let storedPath = checkWithFileManager()

        guard let existingPath = storedPath else {
            doDownload(path: storagePath)
            return
        }
        initiatePlayer(withfile: existingPath)
    }
    
    //MARK:- Check for existing file
    func checkWithFileManager () -> URL? {
        let fm = FileManager.default
        let docsurl = try! fm.url(for:.documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
        let storedPath = docsurl.appendingPathComponent(Constants.VIDEONAME)
        if fm.fileExists(atPath: storedPath.path) {
            return storedPath
        }
        return nil
    }
    
    //MARK: - Intiate player
    func initiatePlayer (withfile atPath: URL) {
        avPlayer = VideoPlayerViewController()
        let player = AVPlayer(url: atPath)
        avPlayer.player = player
        present(avPlayer, animated: true, completion: nil)
    }
    
    //MARK: - Web request handlers
    func getDocumentsDirectory () -> URL{
        let documentDirectory = NSSearchPathForDirectoriesInDomains(                         .documentDirectory,
                    .userDomainMask,
                    true)
        print( documentDirectory[0])
        let documentsUrl:URL =  FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let destinationFileUrl = documentsUrl.appendingPathComponent(Constants.VIDEONAME)
        return destinationFileUrl
    }
    
    func doDownload(path toStore: URL) {
        overlayViewController = self.storyboard?.instantiateViewController(withIdentifier: "overlay") as? OverlayViewController
        overlayViewController.pathToStore = toStore
        self.present(overlayViewController, animated: true, completion: nil)
    }
}

